*******************************************************
 GREATIS OBJECT INSPECTOR EXAMPLES
 Copyright (C) 2003 Greatis Software
*******************************************************

This example demonstrates how to register the additional
property. The example contains two ways to do it:

Way1: using non-published property of the component to 
set/get the new property value

Way2: using direct access to the selected instance to 
set/get the new property value
