*******************************************************
 GREATIS OBJECT INSPECTOR EXAMPLES
 Copyright (C) 2002-2003 Greatis Software
*******************************************************

This example demonstrates how to use 
TDBInspector component.