*******************************************************
 GREATIS OBJECT INSPECTOR EXAMPLES
 Copyright (C) 2003 Greatis Software
*******************************************************

This example demonstrates how to create and fill 
the drop-down list.