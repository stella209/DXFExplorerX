*******************************************************
 GREATIS PROPERTY INTERFACE EXAMPLES
 Copyright (C) 2002 Greatis Software
*******************************************************

This example demonstrates how to do some operation for 
each compatible property of each component on the form.