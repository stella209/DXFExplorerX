*******************************************************
 GREATIS OBJECT INSPECTOR EXAMPLES
 Copyright (C) 2002 Greatis Software
*******************************************************

This example demonstrates how to call external editor
for some properties using TPropertyEditor descendant.