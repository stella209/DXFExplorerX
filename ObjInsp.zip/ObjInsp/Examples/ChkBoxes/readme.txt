*******************************************************
 GREATIS OBJECT INSPECTOR EXAMPLES
 Copyright (C) 2002 Greatis Software
*******************************************************

This example demonstrates how to use check boxes for 
Boolean type properties.